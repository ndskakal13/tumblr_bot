require 'tumblr_client'

USERNAME = "benabot"

def createClient
	
	 # authenticate via OAuth
    client = Tumblr::Client.new({
        # credentials
        :consumer_key => ENV['CONSUMER_KEY'],
        :consumer_secret => ENV['CONSUMER_SECRET'],
        #:oauth_token => ENV['OAUTH_TOKEN'],
        #:oauth_token_secret => ENV['OAUTH_TOKEN_SECRET']
    })
	
	return client

end

def createPost(client)
	
	client.text(USERNAME, title: "here is a title", body: "here is the body")

   
end

def answerAsks
	
	asks = client.submissions(USERNAME, limit: 3)['posts']

    asks.each do |ask|
        # only answer asks
        if ask['type'] != 'answer'
            return
        end

        response = "wow neato"
        tags = "cool, stuff"
        client.edit(USERNAME,
            id: ask['id'],
            answer: response,
            state: 'published',
            tags: tags)

end
